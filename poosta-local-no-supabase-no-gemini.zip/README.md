# پوستا (Poosta) — Skincare AI

React + TypeScript + Vite + Tailwind + Zustand + Supabase.

## چرا این استک
- **React + TypeScript + Vite**: تایپ‌های مشترک (`src/types`) بین سرویس‌ها و کامپوننت‌ها خطاها را زود نشان می‌دهد؛ Vite برای dev سریع.
- **Tailwind**: پیاده‌سازی سریع دیزاین‌سیستم قبلی (رنگ‌ها/رادیوس‌ها در `tailwind.config.ts` عیناً از پروتوتایپ منتقل شده‌اند).
- **Zustand**: state ساده و کم‌حجم بدون boilerplate رداکس؛ با `persist` روی localStorage ذخیره می‌شود (سوییچ‌پوینت به Supabase realtime بعداً).
- **Supabase**: Postgres + Auth + Storage + RLS، مناسب MVP سریع بدون بک‌اند اختصاصی.

## اجرا
```bash
npm install
cp .env.example .env      # اگر Supabase دارید، مقادیر را پر کنید؛ وگرنه خالی بگذارید (mock کار می‌کند)
npm run dev
```

## ساختار
```
src/
  types/          مدل‌های دامنه (Skin, Product, Routine, User) — قرارداد بین سرویس و UI
  lib/             supabaseClient.ts — isSupabaseConfigured flag
  data/            fallback/mock (mockProducts, mockIngredients, interactionRules, mockBarcodes)
  services/        تمام منطق‌های swap-ready (لیست زیر)
  store/           useAppStore.ts (zustand) — تنها منبع state
  hooks/           useAuth, useSkinScan, useProducts, useRoutine
  components/      ui/ (Button, Card, Chip, ScoreRing...), layout/ (BottomNav, TopBar), product/
  pages/           هر صفحه = یک route
supabase/schema.sql  دیتابیس کامل Postgres + RLS
```

## سرویس‌ها و swap-point هرکدام
| سرویس | الان | برای اتصال واقعی |
|---|---|---|
| `skinAnalysisService` | mock وزن‌دار | بدنه‌ی `analyzeSkin` را با fetch به Vision API عوض کنید؛ شکل خروجی ثابت می‌ماند |
| `productService` | `MOCK_PRODUCTS` | با `isSupabaseConfigured` خودکار سراغ جدول `products` می‌رود |
| `recommendationEngine` | — | خالص و بدون وابستگی به UI/بک‌اند؛ نیازی به تغییر ندارد |
| `interactionChecker` | `INTERACTION_RULES` محلی | جدول `product_interactions` |
| `weatherService` | random mock | Open-Meteo/OpenWeather API |
| `barcodeService` | `productService.findByBarcode` | یک API بارکد واقعی + دوربین |
| `coachService` | rule-based | یک Edge Function که به Claude/LLM وصل شود؛ `buildContext`/شکل پیام عوض نمی‌شود |
| `authService` | mock local user | Supabase Auth (ایمیل/OTP از قبل سیم‌کشی شده) |

## دیتابیس
`supabase/schema.sql` را در Supabase SQL editor اجرا کنید: تمام جدول‌های خواسته‌شده (products, brands, ingredients, routines, routine_logs, ai_conversations, ...) + RLS (هرکس فقط داده‌ی خودش را می‌بیند؛ کاتالوگ محصول public-read).

## قدم بعدی پیشنهادی
1. پروژه Supabase بسازید → `.env` را پر کنید → `schema.sql` را اجرا کنید → seed محصولات از `src/data/mockProducts.ts`.
2. `skinAnalysisService` را به یک Vision API واقعی وصل کنید.
3. `coachService.reply` را به یک LLM واقعی (با context injection) وصل کنید.


## Product catalog seed
The expanded Iran-market catalog is included at `src/data/productCatalog.json` (75 products). `productService` uses Supabase when configured and this catalog as the local fallback. Unknown price/barcode fields are intentionally null.
