import http from 'node:http';
const PORT=Number(process.env.PORT||8787);
function send(res,status,body){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'GET,POST,OPTIONS'});res.end(JSON.stringify(body));}
http.createServer((req,res)=>{
  if(req.method==='OPTIONS') return send(res,204,{});
  const path=req.url?.split('?')[0];
  if(path==='/health') return send(res,200,{ok:true,provider:'local'});
  return send(res,404,{error:'Not found'});
}).listen(PORT,()=>console.log(`Poosta local API: http://localhost:${PORT}`));
