# Poosta — Real Skin Vision Analysis

The scan now calls `/api/skin-analysis`. The backend sends the image to Gemini's multimodal Interactions API and requests structured JSON. The API key stays server-side.

## Setup

Create `.env` in the project root:

```env
GEMINI_API_KEY=YOUR_KEY
GEMINI_MODEL=gemini-3.6-flash
PORT=8787
```

Do not prefix `GEMINI_API_KEY` with `VITE_`.

## Run

Terminal 1:

```bash
npm run api
```

Terminal 2:

```bash
npm run dev
```

Vite proxies `/api/*` to `http://localhost:8787`.

## Optional remote endpoint

```env
VITE_SKIN_AI_ENDPOINT=https://your-backend.example/api/skin-analysis
```

## Output

The model returns image suitability, face-count/frontal checks, eight visual skin metrics, observations, limitations and a confidence signal. The server recalculates `overallScore` from the eight metric values.

## Important limitation

This is a consumer visual skin assessment, not a dermatological diagnosis. Image-based estimates such as hydration and oiliness are visual proxies and can be wrong. Keep the medical disclaimer and do not market the output as diagnosis.
